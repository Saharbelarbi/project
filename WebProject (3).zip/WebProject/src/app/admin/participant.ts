export class participant {

    constructor(
        public id: number,
        public name: string,
        
        public email:string,
        public adress: string,
    
        ) { }
}