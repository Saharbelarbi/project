import { Formateur } from './formateur';

describe('Formateur', () => {
  it('should create an instance', () => {
    expect(new Formateur()).toBeTruthy();
  });
});
