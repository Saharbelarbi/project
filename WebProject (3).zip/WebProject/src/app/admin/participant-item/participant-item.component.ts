import { Component, OnInit,Input } from '@angular/core';
import { FakeParticipantService } from '../fake-participant.service';

@Component({
  selector: 'app-participant-item',
  templateUrl: './participant-item.component.html',
  styleUrls: ['./participant-item.component.css']
})
export class ParticipantItemComponent implements OnInit {
  @Input() participant: any;

  constructor(private participantService : FakeParticipantService) { }

  ngOnInit(): void {
  }
  onDelete()
  {
this.participantService.delete(this.participant);
  }
}
