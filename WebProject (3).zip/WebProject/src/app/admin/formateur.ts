export class Formateur {

    constructor(
        public id: number,
        public nom: string,
        public prenom: string,
        public Adresse: string,
        public Email: string,
        public Domaine: string
       ) { }
}
