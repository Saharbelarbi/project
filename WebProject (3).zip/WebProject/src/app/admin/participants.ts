import { participant } from './participant';
export const PARTICIPANTITEMS: participant[] = [
{
    id: 1,
name: 'Web',
email:'belarbisamar@gmail.com',
adress: 'tunis'

},


   
];