import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formateur-edit-form',
  templateUrl: './formateur-edit-form.component.html',
  styleUrls: ['./formateur-edit-form.component.css']
})
export class FormateurEditFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
