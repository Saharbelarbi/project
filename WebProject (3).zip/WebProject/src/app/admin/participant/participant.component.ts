import { Component, OnInit } from '@angular/core';
import { FakeParticipantService } from '../fake-participant.service';

@Component({
  selector: 'app-participant',
  templateUrl: './participant.component.html',
  styleUrls: ['./participant.component.css']
})
export class ParticipantComponent implements OnInit {
  participantItems ;
  constructor(private participantService : FakeParticipantService ) { }

  ngOnInit(): void {
    this.participantItems = this.participantService.get();
  }

}
