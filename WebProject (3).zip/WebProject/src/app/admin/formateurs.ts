import { Formateur } from './formateur';
export const FORMATEURITEMS: Formateur[] = [
    {
     id: 1,
     nom: "sahar",
     prenom: "bearbi",
     Adresse: "tunis",
     Email: "belarbisahar81@gmail.com",
     Domaine: "developpement informatique"
    },
    
    
];