import { InscriptionDisabledDirective } from './inscription-disabled.directive';

describe('InscriptionDisabledDirective', () => {
  it('should create an instance', () => {
    const directive = new InscriptionDisabledDirective();
    expect(directive).toBeTruthy();
  });
});
